package com.example.bcw;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SpecifyTargetActivity2 extends AppCompatActivity {

    // creating instance of java class
    DatabaseHelper4 myDb;
    TextView back, next;
    EditText editText_que8, editText_que9, editText_que10;
    TextView textView_que8, textView_que9, textView_que10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_specify_target2);

        // calling the database helper constructor
        myDb = new DatabaseHelper4(this);

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);

        editText_que8 = (EditText) findViewById(R.id.editText_que8);
        editText_que9 = (EditText) findViewById(R.id.editText_que9);
        editText_que10 = (EditText) findViewById(R.id.editText_que10);
        textView_que8 = (TextView) findViewById(R.id.textView_que8);
        textView_que9 = (TextView) findViewById(R.id.textView_que9);
        textView_que10 = (TextView) findViewById(R.id.textView_que10);

        // Intent
        /*back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(SpecifyTargetActivity2.this, SpecifyTargetActivity.class);
                startActivity(back_intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next_intent = new Intent(SpecifyTargetActivity2.this, IdentifyNeedActivity.class);
                startActivity(next_intent);
            }
        });

         */

        addData();
        viewAll();
    }

    // Add Data Method
    public void addData()
    {

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText_que8.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que8.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                editText_que9.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que9.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                editText_que10.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que10.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                String d1 , d2, d3 ;
                d1 = textView_que8.getText().toString();
                d2 = textView_que9.getText().toString();
                d3 = textView_que10.getText().toString();
                boolean isInserted =  myDb.insertData4(
                        d1,
                        editText_que8.getText().toString(),
                        d2,
                        editText_que9.getText().toString(),
                        d3,
                        editText_que10.getText().toString());

                if (isInserted == true)
                {
                    if (editText_que8.getText().toString().equals("") || editText_que9.getText().toString().equals("") || editText_que10.getText().toString().equals("")) {
                        if (editText_que8.getText().toString().equals("")) {
                            editText_que8.setError("Field is required");
                        }
                        if (editText_que9.getText().toString().equals("")) {
                            editText_que9.setError("Field is required");
                        }
                        if (editText_que10.getText().toString().equals("")) {
                            editText_que10.setError("Field is required");
                        }
                    } else {
                        Toast.makeText(SpecifyTargetActivity2.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        Intent next_intent = new Intent(SpecifyTargetActivity2.this, IdentifyNeedActivity.class);
                        startActivity(next_intent);
                    }
                }
                else
                {
                    Toast.makeText(SpecifyTargetActivity2.this,"Data doesn't Inserted",Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    // view Data
    public void viewAll()
    {
        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent back_intent = new Intent(ProblemActivity.this, StartActivity4.class);
                // startActivity(back_intent);
//                Cursor res = myDb.getData4();
//                if (res.getCount() == 0)
//                {
//                    // show message
//                    showMessage("Error", "Nothing Found");
//                    return;
//                }
//
//                StringBuffer buffer = new StringBuffer();
//                while (res.moveToNext())
//                {
//                    buffer.append("ID : "+res.getString(0)+"\n");
//                    buffer.append("Que1 : "+res.getString(1)+"\n");
//                    buffer.append("Ans1 : "+res.getString(2)+"\n");
//                    buffer.append("Que2 : "+res.getString(3)+"\n");
//                    buffer.append("Ans2 : "+res.getString(4)+"\n");
//                    buffer.append("Que3 : "+res.getString(5)+"\n");
//                    buffer.append("Ans3 : "+res.getString(6)+"\n");
//                }
//                // show all data
//                showMessage("Data",buffer.toString());
                finish();
            }
        });

    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}