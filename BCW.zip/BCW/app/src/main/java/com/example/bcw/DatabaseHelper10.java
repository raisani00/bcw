package com.example.bcw;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper10 extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "bcw10.db";
    public static final String TABLE_NAME = "bcw_table10";
    public static final String COL_1 = "ID";

    public static final String COL_2 = "Title1";
    public static final String COL_3 = "Que1";
    public static final String COL_4 = "check1";
    public static final String COL_5 = "Que2";
    public static final String COL_6 = "Ans1";

    public static final String COL_7 = "Title2";
    public static final String COL_8 = "Que3";
    public static final String COL_9 = "check2";
    public static final String COL_10 = "Que4";
    public static final String COL_11 = "Ans2";
    public DatabaseHelper10(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // creating table
        db.execSQL("create table "+ TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT,Title1 TEXT, Que1 TEXT, check1 TEXT,Que2 TEXT,Ans1 TEXT,Title2 TEXT, Que3 TEXT, check2 TEXT,Que4 TEXT,Ans2 TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
// DROP TABLE IN CASE OF ALREADY CREATION
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);
    }

    // method to insert data
    public boolean insertData10(String t1 , String que1, String check1, String que2, String ans1,String t2 , String que3, String check2, String que4, String ans2)
    {
        // JUST FOR CHECKING DATABASE
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,t1);
        contentValues.put(COL_3,que1);
        contentValues.put(COL_4,check1);
        contentValues.put(COL_5,que2);
        contentValues.put(COL_6,ans1);

        contentValues.put(COL_7,t2);
        contentValues.put(COL_8,que3);
        contentValues.put(COL_9,check2);
        contentValues.put(COL_10,que4);
        contentValues.put(COL_11,ans2);
        long result = db.insert(TABLE_NAME,null,contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    // Get Data table 1
    public Cursor getData10()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }

    // Create method to view data
    public Cursor viewData10()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        //Cursor cursor1 = db.rawQuery("select * from "+TABLE_NAME,null);
        Cursor cursor1 = db.rawQuery("SELECT * FROM "+TABLE_NAME+" ORDER BY ID DESC LIMIT 1",null);
        return cursor1;
    }

}

