package com.example.bcw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class BcwMainActivity extends AppCompatActivity {

    ImageView wheel_main;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bcw_main);

        wheel_main = (ImageView) findViewById(R.id.wheel_main);
        // Intent
        wheel_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent wheel_intent = new Intent(BcwMainActivity.this, MainActivity.class);
                startActivity(wheel_intent);
            }
        });
    }
}