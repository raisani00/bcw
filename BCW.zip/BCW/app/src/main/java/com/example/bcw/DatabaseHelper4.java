package com.example.bcw;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper4 extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "bcw4.db";
    public static final String TABLE_NAME = "bcw_table4";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "Que1";
    public static final String COL_3 = "Ans1";
    public static final String COL_4 = "Que2";
    public static final String COL_5 = "Ans2";
    public static final String COL_6 = "Que3";
    public static final String COL_7 = "Ans3";

    public DatabaseHelper4(@Nullable Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // creating table
        db.execSQL("create table "+ TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT,Que1 TEXT,Ans1 TEXT,Que2 TEXT,Ans2 TEXT,Que3 TEXT,Ans3 TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // DROP TABLE IN CASE OF ALREADY CREATION
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        onCreate(db);

    }

    // method to insert data
    public boolean insertData4(String que1 , String ans1 , String que2, String ans2 , String que3 , String ans3)
    {
        // JUST FOR CHECKING DATABASE
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, que1);
        contentValues.put(COL_3,ans1);
        contentValues.put(COL_4, que2);
        contentValues.put(COL_5,ans2);
        contentValues.put(COL_6, que3);
        contentValues.put(COL_7,ans3);
        long result = db.insert(TABLE_NAME,null,contentValues);
        if (result == -1)
            return false;
        else
            return true;
    }

    // Get Data table 1
    public Cursor getData4()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }

    // Create method to view data
    public Cursor viewData4()
    {
        SQLiteDatabase db = this.getReadableDatabase();
        //Cursor cursor1 = db.rawQuery("select * from "+TABLE_NAME,null);
        Cursor cursor1 = db.rawQuery("SELECT * FROM "+TABLE_NAME+" ORDER BY ID DESC LIMIT 1",null);
        return cursor1;
    }

}

