package com.example.bcw;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TargetActivity extends AppCompatActivity {
    // creating instance of java class
    DatabaseHelper2 myDb;
    TextView back, next, textView_que4;
    EditText editText_que4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_target);

        // calling the database helper constructor
        myDb = new DatabaseHelper2(this);

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);
        editText_que4 = (EditText) findViewById(R.id.editText_que4);
        textView_que4 = (TextView) findViewById(R.id.textView_que4);

        addData();
        viewAll();

        // Intent
       /* back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(TargetActivity.this, ProblemActivity.class);
                startActivity(back_intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next_intent = new Intent(TargetActivity.this, SpecifyTargetActivity.class);
                startActivity(next_intent);
            }
        });

        */
    }

    // Add Data Method
    public void addData()
    {

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText_que4.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que4.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                String d1 ;
                d1 = textView_que4.getText().toString();
                boolean isInserted =  myDb.insertData(
                        d1,
                        editText_que4.getText().toString());

                if (isInserted == true)
                {
                    if (editText_que4.getText().toString().equals("")){
                        editText_que4.setError("field is required");
                    }else {
                        Toast.makeText(TargetActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        Intent next_intent = new Intent(TargetActivity.this, SpecifyTargetActivity.class);
                        startActivity(next_intent);
                    }
                }
                else
                {
                    Toast.makeText(TargetActivity.this,"Data doesn't Inserted",Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    // view Data
    public void viewAll()
    {
        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent back_intent = new Intent(ProblemActivity.this, StartActivity4.class);
                // startActivity(back_intent);
//                Cursor res = myDb.getData();
//                if (res.getCount() == 0)
//                {
//                    // show message
//                    showMessage("Error", "Nothing Found");
//                    return;
//                }
//
//                StringBuffer buffer = new StringBuffer();
//                while (res.moveToNext())
//                {
//                    buffer.append("ID : "+res.getString(0)+"\n");
//                    buffer.append("Que1 : "+res.getString(1)+"\n");
//                    buffer.append("Ans1 : "+res.getString(2)+"\n");
//
//                }
//                // show all data
//                showMessage("Data",buffer.toString());
                finish();
            }
        });

    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

}