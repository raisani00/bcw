package com.example.bcw;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class IdentifyFunctionActivity2 extends AppCompatActivity {

    // creating instance of java class
    DatabaseHelper8 myDb;
    TextView back, next;
    EditText editText_que17, editText_que18;
    RadioGroup radioGroup, radioGroup1;
    RadioButton selectedRadioButton, selectedRadioButton2;
    TextView textView_title1, textView_que21, textView_que22;
    TextView textView_title2, textView_que23, textView_que24;
    RelativeLayout rl_main,rl_main1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identify_function2);

        // calling the database helper constructor
        myDb = new DatabaseHelper8(this);

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);
        rl_main=findViewById(R.id.rl_main);
        rl_main1=findViewById(R.id.rl_main1);

        editText_que17 = (EditText) findViewById(R.id.editText_que17);
        editText_que18 = (EditText) findViewById(R.id.editText_que18);
        textView_title1 = (TextView) findViewById(R.id.textView_title1);
        textView_title2 = (TextView) findViewById(R.id.textView_title2);
        textView_que21 = (TextView) findViewById(R.id.textView_que21);
        textView_que22 = (TextView) findViewById(R.id.textView_que22);
        textView_que23 = (TextView) findViewById(R.id.textView_que23);
        textView_que24 = (TextView) findViewById(R.id.textView_que24);

        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        radioGroup1 = (RadioGroup) findViewById(R.id.radioGroup1);


        // Intent

        /*back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(IdentifyFunctionActivity2.this, IdentifyFunctionActivity.class);
                startActivity(back_intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next_intent = new Intent(IdentifyFunctionActivity2.this, IdentifyFunctionActivity3.class);
                startActivity(next_intent);
            }
        });
         */

        addData();
        viewAll();
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.rb1){
                    textView_que22.setVisibility(View.INVISIBLE);
                    editText_que17.setVisibility(View.INVISIBLE);
                    Log.e(TAG, "onCheckedChanged: yes" );
                } else if (checkedId==R.id.rb2){
                    textView_que22.setVisibility(View.VISIBLE);
                    editText_que17.setVisibility(View.VISIBLE);
                    Log.e(TAG, "onCheckedChanged: No" );
                }
            }
        });
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.rb1){
                    textView_que22.setVisibility(View.INVISIBLE);
                    editText_que17.setVisibility(View.INVISIBLE);
                    rl_main.setVisibility(View.INVISIBLE);
                    Log.e(TAG, "onCheckedChanged: yes" );
                } else if (checkedId==R.id.rb2){
                    textView_que22.setVisibility(View.VISIBLE);
                    editText_que17.setVisibility(View.VISIBLE);
                    rl_main.setVisibility(View.VISIBLE);
                    Log.e(TAG, "onCheckedChanged: No" );
                }
            }
        });
        radioGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId == R.id.rb3){
                    textView_que24.setVisibility(View.INVISIBLE);
                    editText_que18.setVisibility(View.INVISIBLE);
                    rl_main1.setVisibility(View.INVISIBLE);
                    Log.e(TAG, "onCheckedChanged: yes" );
                } else if (checkedId==R.id.rb4){
                    textView_que24.setVisibility(View.VISIBLE);
                    editText_que18.setVisibility(View.VISIBLE);
                    rl_main1.setVisibility(View.VISIBLE);
                    Log.e(TAG, "onCheckedChanged: No" );
                }
            }
        });
    }

    // Add Data Method
    public void addData()
    {

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText_que17.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que17.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                editText_que18.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que18.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                String t1, d1 , d2, t2, d3, d4 ;
                t1 = textView_title1.getText().toString();
                d1 = textView_que21.getText().toString();
                d2 = textView_que22.getText().toString();
                t2 = textView_title2.getText().toString();
                d3 = textView_que23.getText().toString();
                d4 = textView_que24.getText().toString();

                // get the selected RadioButton of the group
                selectedRadioButton  = (RadioButton)findViewById(radioGroup.getCheckedRadioButtonId());
                //get RadioButton text
                String SaveString1 = selectedRadioButton.getText().toString();
                // display it as Toast to the user

                // get the selected RadioButton of the group
                selectedRadioButton2  = (RadioButton)findViewById(radioGroup1.getCheckedRadioButtonId());
                //get RadioButton text
                String SaveString2 = selectedRadioButton2.getText().toString();
                // display it as Toast to the user

                boolean isInserted =  myDb.insertData8(
                        t1,
                        d1,
                        SaveString1,
                        d2,
                        editText_que17.getText().toString(),
                        t2,
                        d3,
                        SaveString2,
                        d4,
                        editText_que18.getText().toString());

                if (isInserted == true)
                {
                        if (SaveString1.equals("No")&&SaveString2.equals("No")&&editText_que17.getText().toString().equals("")&&editText_que18.getText().toString().equals("")) {
                            if (editText_que17.getText().toString().equals("")) {
                                editText_que17.setError("Field is required");
                            }
                            if (editText_que18.getText().toString().equals("")) {
                                editText_que18.setError("Field is required");
                            }
                        }else if (SaveString1.equals("No")&&SaveString2.equals("No")&&!editText_que17.getText().toString().equals("")&&editText_que18.getText().toString().equals("")) {
                            if (editText_que18.getText().toString().equals("")) {
                                editText_que18.setError("Field is required");
                            }
                        }
                        else if (SaveString1.equals("No")&&SaveString2.equals("No")&&editText_que17.getText().toString().equals("")&&!editText_que18.getText().toString().equals("")) {
                            if (editText_que17.getText().toString().equals("")) {
                                editText_que17.setError("Field is required");
                            }
                        }
                        else if (SaveString1.equals("Yes")&&SaveString2.equals("No")&&editText_que18.getText().toString().equals("")){
                            if (editText_que18.getText().toString().equals("")) {
                                editText_que18.setError("Field is required");
                            }
                        }else if (SaveString1.equals("No")&&SaveString2.equals("Yes")&&editText_que17.getText().toString().equals("")){
                            if (editText_que17.getText().toString().equals("")) {
                                editText_que17.setError("Field is required");
                            }
                        }
                        else {
                            Toast.makeText(IdentifyFunctionActivity2.this, "Data Inserted", Toast.LENGTH_LONG).show();
                            Intent next_intent = new Intent(IdentifyFunctionActivity2.this, IdentifyFunctionActivity3.class);
                            startActivity(next_intent);
                        }
                    }
                else
                {
                    Toast.makeText(IdentifyFunctionActivity2.this,"Data doesn't Inserted",Toast.LENGTH_LONG).show();
                }

            }
        });

    }

    // view Data
    public void viewAll()
    {
        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Intent back_intent = new Intent(ProblemActivity.this, StartActivity4.class);
                // startActivity(back_intent);
//                Cursor res = myDb.getData8();
//                if (res.getCount() == 0)
//                {
//                    // show message
//                    showMessage("Error", "Nothing Found");
//                    return;
//                }
//
//                StringBuffer buffer = new StringBuffer();
//                while (res.moveToNext())
//                {
//                    buffer.append("ID : "+res.getString(0)+"\n");
//                    buffer.append("Title1 : "+res.getString(1)+"\n");
//                    buffer.append("Que1 : "+res.getString(2)+"\n");
//                    buffer.append("check1 : "+res.getString(3)+"\n");
//                    buffer.append("Que2 : "+res.getString(4)+"\n");
//                    buffer.append("Ans1 : "+res.getString(5)+"\n");
//                    buffer.append("Title2 : "+res.getString(6)+"\n");
//                    buffer.append("Que3 : "+res.getString(7)+"\n");
//                    buffer.append("check2 : "+res.getString(8)+"\n");
//                    buffer.append("Que4 : "+res.getString(9)+"\n");
//                    buffer.append("Ans4 : "+res.getString(10)+"\n");
//                }
//                // show all data
//                showMessage("Data",buffer.toString());
                finish();
            }
        });

    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}