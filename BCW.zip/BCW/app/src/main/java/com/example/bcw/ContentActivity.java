package com.example.bcw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ContentActivity extends AppCompatActivity {

    TextView back, next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);
        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(ContentActivity.this, PolicyCategoryActivity.class);
                startActivity(back_intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next_intent = new Intent(ContentActivity.this, TechniquesActivity.class);
                startActivity(next_intent);
            }
        });
    }
}