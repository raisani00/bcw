package com.example.bcw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView bcw, start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bcw = (TextView) findViewById(R.id.bcw);
        start = (TextView) findViewById(R.id.start);
        // Intent
        bcw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bcw_intent = new Intent(MainActivity.this, IntroductionActivity.class);
                startActivity(bcw_intent);
            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent start_intent = new Intent(MainActivity.this, StartActivity.class);
                startActivity(start_intent);
            }
        });
    }
}