package com.example.bcw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class PolicyCategoryActivity extends AppCompatActivity {

    TextView back, next;
    ListView data_selected;
    ArrayAdapter adapter1;
    LinearLayout l1,l2,l3,l4,l5,l6,l7,l8,l9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_policy_category);

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);
       // data_selected = (ListView) findViewById(R.id.data_selected);
        l1 = (LinearLayout) findViewById(R.id.l1);
        l2 = (LinearLayout) findViewById(R.id.l2);
        l3 = (LinearLayout) findViewById(R.id.l3);
        l4 = (LinearLayout) findViewById(R.id.l4);
        l5 = (LinearLayout) findViewById(R.id.l5);
        l6 = (LinearLayout) findViewById(R.id.l6);
        l7 = (LinearLayout) findViewById(R.id.l7);
        l8 = (LinearLayout) findViewById(R.id.l8);
        l9 = (LinearLayout) findViewById(R.id.l9);
        Bundle bundle = getIntent().getExtras();
        ArrayList<String> arrayList = bundle.getStringArrayList("selected_list");
        //adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,arrayList);
        //data_selected.setAdapter(adapter1);
        if (arrayList.contains("Education"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l1.setVisibility(LinearLayout.VISIBLE);
        }
        if (arrayList.contains("Persuasion"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l2.setVisibility(LinearLayout.VISIBLE);
        }
        if (arrayList.contains("Incentivisation"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l3.setVisibility(LinearLayout.VISIBLE);
        }
        if (arrayList.contains("Coercison"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l4.setVisibility(LinearLayout.VISIBLE);
        }
        if (arrayList.contains("Training"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l5.setVisibility(LinearLayout.VISIBLE);
        }
        if (arrayList.contains("Enablement"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l6.setVisibility(LinearLayout.VISIBLE);
        }
        if (arrayList.contains("Modelling"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l7.setVisibility(LinearLayout.VISIBLE);
        }
        if (arrayList.contains("Environmental Restructing"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l8.setVisibility(LinearLayout.VISIBLE);
        }
        if (arrayList.contains("Restructions"))
        {
            //Toast.makeText(PolicyCategoryActivity.this,"Data here...",Toast.LENGTH_SHORT).show();
            l9.setVisibility(LinearLayout.VISIBLE);
        }

        //data.setText((CharSequence) arrayList);

        //Intent i = getIntent();
        //String[] myString = i.getStringArrayExtra("selected_list");
        //data.setText(Arrays.toString(myString));
        //data.setText(getIntent().getStringExtra("selected_list"));
        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(PolicyCategoryActivity.this, SelectedInterventionActivity.class);
                startActivity(back_intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next_intent = new Intent(PolicyCategoryActivity.this, ContentActivity.class);
                startActivity(next_intent);
            }
        });
    }
}