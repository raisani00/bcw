package com.example.bcw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class StartActivity3 extends AppCompatActivity {

    TextView back, next;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start3);

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);
        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(StartActivity3.this, StartActivity2.class);
                startActivity(back_intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next_intent = new Intent(StartActivity3.this, StartActivity4.class);
                startActivity(next_intent);
            }
        });
    }
}