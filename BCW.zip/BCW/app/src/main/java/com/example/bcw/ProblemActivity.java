package com.example.bcw;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ProblemActivity extends AppCompatActivity {

    // creating instance of java class
    DatabaseHelper myDb;
    TextView back, next;
    EditText editText_que1, editText_que2, editText_que3;
    TextView textView_que1, textView_que2, textView_que3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem);

        // calling the database helper constructor
        myDb = new DatabaseHelper(this);

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);
        editText_que1 = (EditText) findViewById(R.id.editText_que1);
        editText_que2 = (EditText) findViewById(R.id.editText_que2);
        editText_que3 = (EditText) findViewById(R.id.editText_que3);
        textView_que1 = (TextView) findViewById(R.id.textView_que1);
        textView_que2 = (TextView) findViewById(R.id.textView_que2);
        textView_que3 = (TextView) findViewById(R.id.textView_que3);

        addData();
        viewAll();
    }

    // Add Data Method
    public void addData()
    {

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText_que1.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que1.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                editText_que2.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que2.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                editText_que3.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                        editText_que3.setError(null);
                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }

                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });
                String d1 , d2, d3 ;
                d1 = textView_que1.getText().toString();
                d2 = textView_que2.getText().toString();
                d3 = textView_que3.getText().toString();
               boolean isInserted =  myDb.insertData(
                       d1,
                       editText_que1.getText().toString(),
                        d2,
                        editText_que2.getText().toString(),
                        d3,
                        editText_que3.getText().toString());

               if (isInserted == true)
               {
                   if (editText_que1.getText().toString().equals("")||editText_que2.getText().toString().equals("")||editText_que3.getText().toString().equals("")){
                       if (editText_que1.getText().toString().equals("")){
                           editText_que1.setError("Field is required");
                       }
                       if (editText_que2.getText().toString().equals("")){
                           editText_que2.setError("Field is required");
                       }
                       if (editText_que3.getText().toString().equals("")){
                           editText_que3.setError("Field is required");
                       }



                   }else {
                       Toast.makeText(ProblemActivity.this, "Data Inserted", Toast.LENGTH_LONG).show();
                       // dialog.show(ProblemActivity.this,"","Inserting Data...");
                       Intent next_intent = new Intent(ProblemActivity.this, TargetActivity.class);
                       startActivity(next_intent);
                       //dialog.dismiss();
                   }
               }
               else
               {
                   Toast.makeText(ProblemActivity.this,"Data doesn't Inserted",Toast.LENGTH_LONG).show();
               }

            }
        });

    }

    // view Data
    public void viewAll()
    {
        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // Intent back_intent = new Intent(ProblemActivity.this, StartActivity4.class);
               // startActivity(back_intent);
//                Cursor res = myDb.getData();
//                if (res.getCount() == 0)
//                {
//                    // show message
//                    showMessage("Error", "Nothing Found");
//                    return;
//                }
//
//                StringBuffer buffer = new StringBuffer();
//                while (res.moveToNext())
//                {
//                    buffer.append("ID : "+res.getString(0)+"\n");
//                    buffer.append("Que1 : "+res.getString(1)+"\n");
//                    buffer.append("Ans1 : "+res.getString(2)+"\n");
//                    buffer.append("Que2 : "+res.getString(3)+"\n");
//                    buffer.append("Ans2 : "+res.getString(4)+"\n");
//                    buffer.append("Que3 : "+res.getString(5)+"\n");
//                    buffer.append("Ans3 : "+res.getString(6)+"\n");
//                }
//                // show all data
//                showMessage("Data",buffer.toString());
                finish();
            }
        });

    }

    public void showMessage(String title, String message)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}