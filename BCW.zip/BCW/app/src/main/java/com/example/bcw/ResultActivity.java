package com.example.bcw;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    // creating instance of java class
    DatabaseHelper myDb;
    DatabaseHelper2 myDb2;
    DatabaseHelper3 myDb3;
    DatabaseHelper4 myDb4;
    DatabaseHelper5 myDb5;
    DatabaseHelper6 myDb6;
    DatabaseHelper7 myDb7;

    ListView listView1;
    ArrayList<String> list1;
    ArrayAdapter adapter1;

    TextView back, next;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // calling the database helper constructor
        myDb = new DatabaseHelper(this);
        myDb2 = new DatabaseHelper2(this);
        myDb3 = new DatabaseHelper3(this);
        myDb4 = new DatabaseHelper4(this);
        myDb5 = new DatabaseHelper5(this);
        myDb6 = new DatabaseHelper6(this);
        myDb7 = new DatabaseHelper7(this);

        listView1 = (ListView) findViewById(R.id.listView1);

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);

        list1 = new ArrayList<>();
        viewData1();
        viewData2();
        viewData3();
        viewData4();
        viewData5();
        viewData6();
        viewData7();

        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(ResultActivity.this, IdentifyNeedActivity3.class);
                startActivity(back_intent);
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent next_intent = new Intent(ResultActivity.this, IdentifyFunctionActivity.class);
                startActivity(next_intent);
            }
        });
    }
    public void viewData1()
    {
        Cursor cursor = myDb.viewData1();
        if (cursor.getCount() == 0)
        {
            Toast.makeText(ResultActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor.moveToNext())
            {
               // list1.add(cursor.getString(0));
                list1.add(cursor.getString(1));
                list1.add(cursor.getString(2));
                list1.add(cursor.getString(3));
                list1.add(cursor.getString(4));
                list1.add(cursor.getString(5));
                list1.add(cursor.getString(6));
            }
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            listView1.setAdapter(adapter1);
        }
    }

    public void viewData2()
    {
        Cursor cursor2 = myDb2.viewData2();
        if (cursor2.getCount() == 0)
        {
            Toast.makeText(ResultActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor2.moveToNext())
            {
                //list1.add(cursor2.getString(0));
                list1.add(cursor2.getString(1));
                list1.add(cursor2.getString(2));
            }
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            listView1.setAdapter(adapter1);
        }
    }

    public void viewData3()
    {
        Cursor cursor3 = myDb3.viewData3();
        if (cursor3.getCount() == 0)
        {
            Toast.makeText(ResultActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor3.moveToNext())
            {
               // list1.add(cursor3.getString(0));
                list1.add(cursor3.getString(1));
                list1.add(cursor3.getString(2));
                list1.add(cursor3.getString(3));
                list1.add(cursor3.getString(4));
                list1.add(cursor3.getString(5));
                list1.add(cursor3.getString(6));
            }
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            listView1.setAdapter(adapter1);
        }
    }

    public void viewData4()
    {
        Cursor cursor4 = myDb4.viewData4();
        if (cursor4.getCount() == 0)
        {
            Toast.makeText(ResultActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor4.moveToNext())
            {
                //list1.add(cursor4.getString(0));
                list1.add(cursor4.getString(1));
                list1.add(cursor4.getString(2));
                list1.add(cursor4.getString(3));
                list1.add(cursor4.getString(4));
                list1.add(cursor4.getString(5));
                list1.add(cursor4.getString(6));
            }
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            listView1.setAdapter(adapter1);
        }
    }

    public void viewData5()
    {
        Cursor cursor5 = myDb5.viewData5();
        if (cursor5.getCount() == 0)
        {
            Toast.makeText(ResultActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor5.moveToNext())
            {
                //list1.add(cursor5.getString(0));
                list1.add(cursor5.getString(1));
                list1.add(cursor5.getString(2));
                list1.add(cursor5.getString(3));
                list1.add(cursor5.getString(4));
                list1.add(cursor5.getString(5));
                list1.add(cursor5.getString(6));
                list1.add(cursor5.getString(7));
                list1.add(cursor5.getString(8));
                list1.add(cursor5.getString(9));
                list1.add(cursor5.getString(10));
            }
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            listView1.setAdapter(adapter1);
        }
    }

    public void viewData6()
    {
        Cursor cursor6 = myDb6.viewData6();
        if (cursor6.getCount() == 0)
        {
            Toast.makeText(ResultActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor6.moveToNext())
            {
               // list1.add(cursor6.getString(0));
                list1.add(cursor6.getString(1));
                list1.add(cursor6.getString(2));
                list1.add(cursor6.getString(3));
                list1.add(cursor6.getString(4));
                list1.add(cursor6.getString(5));
                list1.add(cursor6.getString(6));
                list1.add(cursor6.getString(7));
                list1.add(cursor6.getString(8));
                list1.add(cursor6.getString(9));
                list1.add(cursor6.getString(10));
            }
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            listView1.setAdapter(adapter1);
        }
    }

    public void viewData7()
    {
        Cursor cursor7 = myDb7.viewData7();
        if (cursor7.getCount() == 0)
        {
            Toast.makeText(ResultActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor7.moveToNext())
            {
               // list1.add(cursor7.getString(0));
                list1.add(cursor7.getString(1));
                list1.add(cursor7.getString(2));
                list1.add(cursor7.getString(3));
                list1.add(cursor7.getString(4));
                list1.add(cursor7.getString(5));
                list1.add(cursor7.getString(6));
                list1.add(cursor7.getString(7));
                list1.add(cursor7.getString(8));
                list1.add(cursor7.getString(9));
                list1.add(cursor7.getString(10));
            }
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            listView1.setAdapter(adapter1);
        }
    }


}