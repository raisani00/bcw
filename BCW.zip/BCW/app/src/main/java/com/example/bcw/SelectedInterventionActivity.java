package com.example.bcw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SelectedInterventionActivity extends AppCompatActivity {

    // creating instance of java class
    //DatabaseHelper myDb;
    DatabaseHelper8 myDb8;
    DatabaseHelper9 myDb9;
    DatabaseHelper10 myDb10;
    DatabaseHelper11 myDb11;
    DatabaseHelper12 myDb12;
    TextView back, next;
    ListView selected_yes;
    ArrayList<String> list1;
    ArrayAdapter adapter1;
    ArrayList<String> list2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_intervention);


        // calling the database helper constructor
        //myDb = new DatabaseHelper(this);
        myDb8 = new DatabaseHelper8(this);
        myDb9 = new DatabaseHelper9(this);
        myDb10 = new DatabaseHelper10(this);
        myDb11 = new DatabaseHelper11(this);
        myDb12 = new DatabaseHelper12(this);

        selected_yes = (ListView) findViewById(R.id.selected_yes);
        list1 = new ArrayList<>();
        list2 = new ArrayList<>();

        back = (TextView) findViewById(R.id.back);
        next = (TextView) findViewById(R.id.next);
        selected_yes.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        selected_yes.setItemChecked(2, true);
        // Intent
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent back_intent = new Intent(SelectedInterventionActivity.this, IdentifyFunctionActivity6.class);
                startActivity(back_intent);
            }
        });

        viewData8();
        viewData9();
        viewData10();
        viewData11();
        viewData12();

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               //Toast.makeText(SelectedInterventionActivity.this,""+list2,Toast.LENGTH_SHORT).show();
               Intent next_intent = new Intent(SelectedInterventionActivity.this, PolicyCategoryActivity.class);
              // next_intent.putExtra("selected_list",list2);
               next_intent.putExtra("selected_list",list2);
               startActivity(next_intent);

            }
        });

        selected_yes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String text = ((TextView)view).getText().toString();
                if (list2.contains(text))
                {
                  //  Toast.makeText(SelectedInterventionActivity.this,text,Toast.LENGTH_SHORT).show();
                }
                else
                {
                    list2.add(text);
                }

                Toast.makeText(SelectedInterventionActivity.this,text,Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void viewData8()
    {
        Cursor cursor8 = myDb8.viewData8();
        if (cursor8.getCount() == 0)
        {
            Toast.makeText(SelectedInterventionActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor8.moveToNext())
            {
                if (cursor8.getString(3).equals("Yes"))
                {
                    list1.add(cursor8.getString(1));
                }

                if (cursor8.getString(8).equals("Yes"))
                {
                    list1.add(cursor8.getString(6));
                }
            }
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            //adapter1 = new ArrayAdapter<>(this,R.layout.cardview,R.id.checkbox_data,list1);
            selected_yes.setAdapter(adapter1);


        }
    }
    public void viewData9()
    {
        Cursor cursor9 = myDb9.viewData9();
        if (cursor9.getCount() == 0)
        {
            Toast.makeText(SelectedInterventionActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor9.moveToNext())
            {
                if (cursor9.getString(3).equals("Yes"))
                {
                    list1.add(cursor9.getString(1));
                }

                if (cursor9.getString(8).equals("Yes"))
                {
                    list1.add(cursor9.getString(6));
                }
            }
           // adapter1 = new ArrayAdapter<>(this,R.layout.cardview,R.id.checkbox_data,list1);
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            selected_yes.setAdapter(adapter1);

        }
    }
    public void viewData10()
    {
        Cursor cursor10 = myDb10.viewData10();
        if (cursor10.getCount() == 0)
        {
            Toast.makeText(SelectedInterventionActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor10.moveToNext())
            {
                if (cursor10.getString(3).equals("Yes"))
                {
                    list1.add(cursor10.getString(1));
                }

                if (cursor10.getString(8).equals("Yes"))
                {
                    list1.add(cursor10.getString(6));
                }

            }
           // adapter1 = new ArrayAdapter<>(this,R.layout.cardview,R.id.checkbox_data,list1);
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            selected_yes.setAdapter(adapter1);

        }
    }
    public void viewData11()
    {
        Cursor cursor11 = myDb11.viewData11();
        if (cursor11.getCount() == 0)
        {
            Toast.makeText(SelectedInterventionActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor11.moveToNext())
            {
                if (cursor11.getString(3).equals("Yes"))
                {
                    list1.add(cursor11.getString(1));
                }

                if (cursor11.getString(8).equals("Yes"))
                {
                    list1.add(cursor11.getString(6));
                }
            }
            //adapter1 = new ArrayAdapter<>(this,R.layout.cardview,R.id.checkbox_data,list1);
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list1);
            selected_yes.setAdapter(adapter1);

        }
    }

    public void viewData12()
    {
        Cursor cursor12 = myDb12.viewData12();
        if (cursor12.getCount() == 0)
        {
            Toast.makeText(SelectedInterventionActivity.this,"No Data To Show...",Toast.LENGTH_SHORT).show();
        }
        else
        {
            while (cursor12.moveToNext())
            {
                if (cursor12.getString(3).equals("Yes"))
                {
                    list1.add(cursor12.getString(1));
                }
            }

            //adapter1 = new ArrayAdapter<>(this,R.layout.cardview,R.id.checkbox_data,list1);
            adapter1 = new ArrayAdapter<>(this, android.R.layout.simple_list_item_multiple_choice,list1);
            selected_yes.setAdapter(adapter1);

        }
    }
}